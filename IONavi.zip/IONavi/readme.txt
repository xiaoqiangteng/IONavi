main -> ioNavi.tex
bibliography -> references.bib

Fig.1  -> LED_signals.eps
Fig.2  -> system_architecture.eps
Fig.3  -> station_detection.eps
Fig.4  -> fingerprint.eps
Fig.5a -> hold_in_hand.eps
Fig.5b -> turning_points.eps
Fig.6  -> trajectory_clustering.eps
Fig.7a -> machine_detection_two.eps
Fig.7b -> machine_detection_one.eps
Fig.8  -> MoS.eps
Fig.9a -> trajectories_one.eps
Fig.9b -> trajectories_two.eps
Fig.9c -> trajectories_three.eps
Fig.10a -> experiment_environment.eps
Fig.10b -> snapshot_ioNavi.eps
Fig.11  -> tracking_errors.eps
Fig.12  -> deviation_detection.eps
Fig.13  -> detection_accuracy_time.eps
Fig.14  -> localization_accuracy.eps
Fig.15  -> localization_error_ap.eps
Fig.16 -> trace_clustering.eps
Fig.17a -> estimated_trajectory_one.eps
Fig.17b -> estimated_trajectory_two.eps
Fig.17c -> estimated_trajectory_three.eps

All source files of IONavi have been uploaded to github. If above files have problem, please you download files from https://github.com/xiaoqiangteng/IONavi.

Thanks.


Xiaoqiang Teng
tengxiaoqiang13@nudt.edu.cn